/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vehiculosprueba;

/**
 *
 * @author DONAHI
 */
public class Vehiculosprueba {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Automovil auto = new Automovil("Auto1", 4);
        Bicicleta bicicleta = new Bicicleta("Bici1");

        auto.acelerar(80);
        auto.frenar();

        bicicleta.acelerar(25);
        bicicleta.frenar();
    }
    
}
