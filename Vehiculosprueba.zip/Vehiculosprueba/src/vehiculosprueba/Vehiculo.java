/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehiculosprueba;

/**
 *
 * @author DONAHI
 */
public abstract class Vehiculo implements Conducible {
    protected String nombre;

    public Vehiculo(String nombre) {
        this.nombre = nombre;
    }
}
