/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehiculosprueba;

/**
 *
 * @author DONAHI
 */
public class Bicicleta extends Vehiculo {
    public Bicicleta(String nombre) {
        super(nombre);
    }

    @Override
    public void acelerar(int velocidad) {
        System.out.println(nombre + " está acelerando a " + velocidad + " km/h");
    }

    @Override
    public void frenar() {
        System.out.println(nombre + " está frenando");
    }
}